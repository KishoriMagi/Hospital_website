# Hospital Patient & Test Management Portal

## Project Overview
This project is a complete Hospital Patient & Test Management Portal built as a college project. It manages hospital staff login, patient registration, test requests, and laboratory results.

**IMPORTANT:** This is ONLY the Hospital Portal. There is a completely independent "Diagnostic Laboratory Processing Portal" that processes tests and returns results.

## Architecture
The system follows a completely independent architecture:
- **Hospital Frontend:** HTML5, CSS3, Bootstrap 5, JS
- **Hospital Backend:** Python 3.10+ Flask
- **Database:** SQLite (Independent)
- **Data Exchange:** Dropbox Shared Folder (CSV format)

### Data Flow
1. **Hospital → Laboratory:**
   Hospital Staff registers patient → Creates Test Request → System generates CSV → Uploads to Dropbox `/Hospital_Laboratory_Exchange/Requests/`
   
2. **Laboratory → Hospital:**
   Laboratory processes test → Generates Result CSV → Uploads to Dropbox `/Hospital_Laboratory_Exchange/Results/` → Hospital Staff clicks "Sync Results" → System downloads and displays result.

## Technology Stack
- **Frontend:** HTML5, CSS3, Bootstrap 5, Vanilla JavaScript
- **Backend:** Python (Flask, Flask Blueprints)
- **Database:** SQLite
- **Data Processing:** Pandas
- **Cloud Integration:** Official Dropbox Python SDK

## Installation

1. Clone the repository and navigate to the folder:
   ```bash
   cd Hospital_website
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Configuration:
   Rename `.env.example` to `.env` and configure your settings.
   ```
   SECRET_KEY=your_secret_key
   USE_LOCAL_MOCK=True
   DROPBOX_ACCESS_TOKEN=your_dropbox_token
   DROPBOX_REQUEST_FOLDER=/Hospital_Laboratory_Exchange/Requests
   DROPBOX_RESULT_FOLDER=/Hospital_Laboratory_Exchange/Results
   ```

## Running the Application

1. Start the Flask application:
   ```bash
   python app.py
   ```
   
2. Open your browser and go to `http://127.0.0.1:5000`

### Demo Credentials
- **Staff ID:** HOSP101
- **Password:** admin123

## Using Local Mock Mode
For academic demonstrations without a real Dropbox account, set `USE_LOCAL_MOCK=True` in your `.env` file. The application will use local folders (`mock_dropbox/Requests/` and `mock_dropbox/Results/`) instead of the real Dropbox API.

## Testing
To run tests:
```bash
pytest
```
