def test_login(client, auth):
    response = auth.login()
    assert response.headers['Location'] == '/dashboard'
    
    response = client.get('/dashboard')
    assert b'Dashboard' in response.data

def test_patient_registration(client, auth, app):
    auth.login()
    response = client.post('/patients/create', data={
        'patient_id': 'P1023',
        'patient_name': 'Rahul',
        'age': 23,
        'gender': 'Male',
        'date_of_birth': '2003-05-10',
        'phone': '1234567890',
        'email': 'rahul@example.com',
        'address': 'Test Address',
        'emergency_contact': 'Mom 0987654321',
        'doctor': 'Dr. Kumar',
        'department': 'General'
    })
    
    assert response.headers['Location'] == '/patients'
    
    with app.app_context():
        from database.database import get_db
        db = get_db()
        patient = db.execute('SELECT * FROM patients WHERE patient_id = "P1023"').fetchone()
        assert patient is not None
        assert patient['patient_name'] == 'Rahul'

def test_duplicate_patient_id(client, auth, app):
    auth.login()
    # Create first
    client.post('/patients/create', data={
        'patient_id': 'P1024',
        'patient_name': 'Alice',
        'age': 30,
        'gender': 'Female',
        'date_of_birth': '', 'phone': '', 'email': '', 'address': '', 'emergency_contact': '', 'doctor': '', 'department': ''
    })
    # Attempt duplicate
    response = client.post('/patients/create', data={
        'patient_id': 'P1024',
        'patient_name': 'Bob',
        'age': 25,
        'gender': 'Male',
        'date_of_birth': '', 'phone': '', 'email': '', 'address': '', 'emergency_contact': '', 'doctor': '', 'department': ''
    })
    assert b'already registered' in response.data

def test_test_request_creation(client, auth, app):
    auth.login()
    
    # Register patient
    client.post('/patients/create', data={
        'patient_id': 'P1023', 'patient_name': 'Rahul', 'age': 23, 'gender': 'Male',
        'date_of_birth': '', 'phone': '', 'email': '', 'address': '', 'emergency_contact': '', 'doctor': 'Dr. Kumar', 'department': ''
    })
    
    response = client.post('/test-requests/create', data={
        'patient_id': 'P1023',
        'test_id': 'T1001',
        'test_type': 'CBC',
        'sample_type': 'Blood',
        'priority': 'Normal',
        'requested_date': '2026-10-07',
        'instructions': 'Regular CBC test'
    })
    
    assert response.headers['Location'] == '/test-requests/'
    
    with app.app_context():
        from database.database import get_db
        db = get_db()
        req = db.execute('SELECT * FROM test_requests WHERE test_id = "T1001"').fetchone()
        assert req is not None
        assert req['status'] == 'Sent to Laboratory'
        
        # Check mock upload
        import os
        mock_path = os.path.join(app.config['MOCK_REQUESTS_DIR'], 'test_request_T1001.csv')
        assert os.path.exists(mock_path)
