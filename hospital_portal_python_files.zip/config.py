import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev_secret_key')
    DATABASE = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'instance', 'hospital.db')
    
    # Dropbox Configuration
    USE_LOCAL_MOCK = os.environ.get('USE_LOCAL_MOCK', 'True').lower() == 'true'
    DROPBOX_ACCESS_TOKEN = os.environ.get('DROPBOX_ACCESS_TOKEN', '')
    DROPBOX_REQUEST_FOLDER = os.environ.get('DROPBOX_REQUEST_FOLDER', '/Hospital_Laboratory_Exchange/Requests')
    DROPBOX_RESULT_FOLDER = os.environ.get('DROPBOX_RESULT_FOLDER', '/Hospital_Laboratory_Exchange/Results')
    
    # Local Mock paths (Shared across Hospital and Laboratory portals)
    MOCK_DROPBOX_DIR = os.environ.get('MOCK_EXCHANGE_DIR', r'D:\Hospital_Laboratory_Exchange')
    MOCK_REQUESTS_DIR = os.path.join(MOCK_DROPBOX_DIR, 'Requests')
    MOCK_RESULTS_DIR = os.path.join(MOCK_DROPBOX_DIR, 'Results')
