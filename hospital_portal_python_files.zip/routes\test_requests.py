import os
import csv
from flask import Blueprint, flash, g, redirect, render_template, request, url_for, current_app
from werkzeug.exceptions import abort
from routes.auth import login_required
from database.database import get_db
from services.dropbox_service import DropboxService

bp = Blueprint('test_requests', __name__, url_prefix='/test-requests')

@bp.route('/')
@login_required
def index():
    db = get_db()
    requests = db.execute('SELECT * FROM test_requests ORDER BY created_at DESC').fetchall()
    return render_template('test_requests.html', requests=requests)

@bp.route('/create', methods=('GET', 'POST'))
@login_required
def create():
    db = get_db()
    
    if request.method == 'POST':
        patient_id = request.form['patient_id']
        test_id = request.form['test_id']
        test_type = request.form['test_type']
        sample_type = request.form['sample_type']
        priority = request.form['priority']
        requested_date = request.form['requested_date']
        instructions = request.form['instructions']
        
        error = None
        
        # Validation
        patient = db.execute('SELECT * FROM patients WHERE patient_id = ?', (patient_id,)).fetchone()
        if not patient:
            error = f"Patient ID {patient_id} not found."
            
        elif db.execute('SELECT id FROM test_requests WHERE test_id = ?', (test_id,)).fetchone() is not None:
            error = f"Test ID {test_id} is already in use."
            
        if not test_type or not sample_type or not priority or not requested_date:
            error = "All required fields must be filled."

        if error is not None:
            flash(error, 'danger')
        else:
            # 1. Save to database
            db.execute(
                '''INSERT INTO test_requests (test_id, patient_id, patient_name, age, gender, doctor, 
                   test_type, sample_type, priority, requested_date, instructions)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (test_id, patient_id, patient['patient_name'], patient['age'], patient['gender'], 
                 patient['doctor'], test_type, sample_type, priority, requested_date, instructions)
            )
            db.commit()
            
            # 2. Generate CSV
            temp_dir = os.path.join(current_app.instance_path, 'temp_requests')
            os.makedirs(temp_dir, exist_ok=True)
            csv_filename = f"test_request_{test_id}.csv"
            local_csv_path = os.path.join(temp_dir, csv_filename)
            
            with open(local_csv_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(['Patient_ID', 'Patient_Name', 'Age', 'Gender', 'Doctor', 'Test_ID', 
                                 'Test_Type', 'Sample_Type', 'Priority', 'Requested_Date', 'Instructions'])
                writer.writerow([patient_id, patient['patient_name'], patient['age'], patient['gender'], 
                                 patient['doctor'], test_id, test_type, sample_type, priority, 
                                 requested_date, instructions])
            
            # 3. Upload to Dropbox
            try:
                dropbox_service = DropboxService()
                dropbox_path = dropbox_service.upload_test_request(local_csv_path, test_id)
                
                # Update status
                db.execute("UPDATE test_requests SET status = 'Sent to Laboratory', dropbox_file_path = ? WHERE test_id = ?",
                          (dropbox_path, test_id))
                db.commit()
                
                flash(f'Test Request {test_id} submitted successfully. Uploaded to: Requests/{csv_filename}', 'success')
            except Exception as e:
                flash(f'Failed to upload to Dropbox: {str(e)}', 'danger')
                
            finally:
                if os.path.exists(local_csv_path):
                    os.remove(local_csv_path)

            return redirect(url_for('test_requests.index'))
            
    patients = db.execute('SELECT patient_id, patient_name FROM patients').fetchall()
    return render_template('create_test_request.html', patients=patients)

@bp.route('/<test_id>')
@login_required
def details(test_id):
    db = get_db()
    req = db.execute('SELECT * FROM test_requests WHERE test_id = ?', (test_id,)).fetchone()
    
    if req is None:
        abort(404, f"Test Request id {test_id} doesn't exist.")
        
    return render_template('test_request_details.html', request=req)
