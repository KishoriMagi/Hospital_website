import os
import pandas as pd
from flask import current_app
from database.database import get_db
from services.dropbox_service import DropboxService
import json

class ResultSyncService:
    def __init__(self):
        self.dropbox_service = DropboxService()
        
    def sync_results(self):
        db = get_db()
        synced_count = 0
        errors = []
        try:
            files = self.dropbox_service.list_results()
        except Exception as e:
            errors.append(f"Dropbox Error: {str(e)}")
            return 0, errors
        
        temp_dir = os.path.join(current_app.instance_path, 'temp_results')
        os.makedirs(temp_dir, exist_ok=True)
        
        for filename in files:
            # Check if we already have this result
            # Assuming filename format: test_result_T1001.csv
            if not filename.startswith('test_result_') or not filename.endswith('.csv'):
                continue
                
            test_id = filename.replace('test_result_', '').replace('.csv', '')
            
            existing = db.execute("SELECT id FROM test_results WHERE test_id = ?", (test_id,)).fetchone()
            if existing:
                continue # Already synced
                
            # Download file
            local_path = os.path.join(temp_dir, filename)
            if not self.dropbox_service.download_result(filename, local_path):
                errors.append(f"Failed to download {filename}")
                continue
                
            # Parse with pandas
            try:
                df = pd.read_csv(local_path)
                if df.empty:
                    errors.append(f"File {filename} is empty")
                    continue
                    
                row = df.iloc[0]
                
                # Validation
                req_cols = ['Patient_ID', 'Test_ID', 'Test_Type', 'Result_Status', 'Processed_Date']
                missing_cols = [c for c in req_cols if c not in df.columns]
                if missing_cols:
                    errors.append(f"Missing columns in {filename}: {', '.join(missing_cols)}")
                    continue
                
                file_test_id = str(row['Test_ID'])
                patient_id = str(row['Patient_ID'])
                
                if file_test_id != test_id:
                    errors.append(f"Test ID mismatch in {filename}")
                    continue
                
                # Check against database
                request = db.execute("SELECT * FROM test_requests WHERE test_id = ?", (test_id,)).fetchone()
                if not request:
                    errors.append(f"Unknown Test ID {test_id} in {filename}")
                    continue
                    
                if request['patient_id'] != patient_id:
                    errors.append(f"Patient ID mismatch for Test {test_id} in {filename}")
                    continue
                
                # Store data
                # Extract measurements
                excluded_cols = ['Patient_ID', 'Test_ID', 'Test_Type', 'Result_Status', 'Processed_Date', 'Remarks']
                measurements = {col: str(row[col]) for col in df.columns if col not in excluded_cols}
                result_data_json = json.dumps(measurements)
                
                status = str(row.get('Result_Status', 'Completed'))
                remarks = str(row.get('Remarks', ''))
                processed_date = str(row.get('Processed_Date', ''))
                
                dropbox_path = f"{current_app.config['DROPBOX_RESULT_FOLDER']}/{filename}"
                
                # Insert result
                db.execute(
                    """INSERT INTO test_results (test_id, patient_id, test_type, result_data, result_status, processed_date, remarks, dropbox_file_path)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (test_id, patient_id, request['test_type'], result_data_json, status, processed_date, remarks, dropbox_path)
                )
                
                # Update request status
                new_req_status = 'Abnormal' if status.lower() == 'abnormal' else 'Completed'
                db.execute("UPDATE test_requests SET status = ? WHERE test_id = ?", (new_req_status, test_id))
                db.commit()
                
                synced_count += 1
                
            except Exception as e:
                errors.append(f"Error processing {filename}: {str(e)}")
            finally:
                if os.path.exists(local_path):
                    os.remove(local_path)
                    
        return synced_count, errors
